package com.chz.aaa;

public interface UserMapper //extends BaseMapper<User>
{
}
