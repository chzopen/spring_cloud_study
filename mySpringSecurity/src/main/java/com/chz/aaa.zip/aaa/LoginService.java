package com.chz.aaa;

import com.chz.mySpringSecurity.entity.ResponseResult;
import com.chz.mySpringSecurity.entity.User;

public interface LoginService {
    ResponseResult login(User user);

    ResponseResult logout();
}
